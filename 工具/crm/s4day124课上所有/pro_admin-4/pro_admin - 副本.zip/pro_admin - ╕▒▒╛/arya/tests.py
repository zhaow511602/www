from django.test import TestCase

# v = [11,22,33] + [22,1]
# v = {11, 22, 33} - ({11, 22, 33} - {22, 1})
# print(v)

